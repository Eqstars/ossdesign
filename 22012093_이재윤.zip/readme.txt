target_aim_for_the_unskilled파일의 target_aim.exe실행
1.0.0
startgame, exit 구현
settings 미구현
scoreboard 등록 미구현
